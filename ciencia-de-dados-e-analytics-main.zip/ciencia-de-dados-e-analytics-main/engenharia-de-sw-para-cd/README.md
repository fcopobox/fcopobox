# Disciplina Engenharia de Software para Ciência de Dados
Neste repositório você encontrará materiais referentes à disciplina Engenharia de Software para Ciência de Dados do curso de pós-graduação em Ciência de Dados e Analytics da PUC-Rio. Os materiais aqui encontrados são apenas pequenos complementos a materiais muito mais completos disponíveis no ambiente online, incluindo conteúdo interativo e vídeo aulas, vídeos react com profissionais de referência do mercado, dinâmicas de técnica aplicada, olhar crítico, entre outros.

Mais informações em http://especializacao.ccec.puc-rio.br 
