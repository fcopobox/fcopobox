# Disciplina Visualização de Informação
Neste repositório você encontra alguns materiais de apoio à disciplina Visualização de Informação do curso de pós-graduação em Ciência de Dados e *Analytics* da PUC-Rio.

Na pasta `dados` há alguns arquivos CSV utilizados nos exemplos da disciplina.

Mais informações em http://especializacao.ccec.puc-rio.br 
