Códigos e arquivos de apoio das disciplinas da especialização online **Pós-Graduação em Ciência de Dados e Analytics**, do Departamento de Informática da PUC-Rio.

Coordenação:
* **Prof. Hélio Côrtes Vieira Lopes** (*lopes@inf.puc-rio.br*)
* **Prof. Tatiana Escovedo** (*tatiana@inf.puc-rio.br*)

Mais informações em: https://especializacao.ccec.puc-rio.br/especializacao/ciencia-de-dados-e-analytics

