As orientações de como baixar os datasets estão detalhadas nos notebooks.
