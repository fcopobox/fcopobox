Códigos das disciplinas da especialização online **Pós-Graduação em Interação Humano-Computador e Experiência do Usuário (UX)**, do Departamento de Informática da PUC-Rio.

Coordenação:
* **Prof. Alberto B. Raposo** (*abraposo@inf.puc-rio.br*)
* **Prof. Simone D. J. Barbosa** (*simone@inf.puc-rio.br*)

Mais informações em: https://especializacao.ccec.puc-rio.br/especializacao/interacao-humano-computador-e-experiencia-do-usuario-ux

