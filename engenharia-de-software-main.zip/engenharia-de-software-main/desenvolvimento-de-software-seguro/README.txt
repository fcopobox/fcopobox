Roteiros e códigos-fontes das técnicas aplicadas das aulas 1, 2 e 3 da disciplina de desenvolvimento de software seguro do curso de pós-graduação em engenharia de software do DI/CCEC/PUC-Rio.
