# Introdução a Criação de Páginas Web
## Aula 1
### Prof. Alexandre Meslin

Conteúdo

* [__meu-site__](./meu-site): Jogo completo Whac-A-Mole construído apenas usando HTML e imagens
* [__noticias__](./noticias): Portal de notícias
* [__Exercícios__](./Exercícios/README.md): Exercícios de HTML.

Outros links que podem ser interessantes:
* [Aula 2](../aula-2): Nossa segunda aula
* [Aula 3](../aula-3): Nossa terceira aula
* [Imagens](../imagens): Diretório com as imagens que vamos usar
