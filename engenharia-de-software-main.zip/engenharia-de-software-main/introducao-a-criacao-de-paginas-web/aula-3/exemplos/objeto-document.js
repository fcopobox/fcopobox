var botao = document.getElementById('idButton');

botao.addEventListener('click', trataCick);

document.getElementById('idButton').addEventListener('click', trataCick);

