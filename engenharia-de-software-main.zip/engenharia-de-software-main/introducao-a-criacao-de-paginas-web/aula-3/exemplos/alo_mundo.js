document.getElementById('btnIniciar').addEventListener('click', mostraMensagem);
function mostraMensagem() {
    document.getElementById('lugar').innerHTML = 'Alô Mundo!!!';
}

