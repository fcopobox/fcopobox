from sqlalchemy.orm import declarative_base

# Cria uma classe Base para o instanciamento de novos objetos.
Base = declarative_base()