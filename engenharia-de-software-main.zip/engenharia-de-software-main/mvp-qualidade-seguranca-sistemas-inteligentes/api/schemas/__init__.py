from schemas.paciente_schema import PacienteSchema,  PacienteBuscaSchema, PacienteViewSchema, PacienteDelSchema, \
                                    apresenta_pacientes, apresenta_paciente
                                        
from schemas.error_schema import ErrorSchema
                                    