Códigos das disciplinas da especialização online **Pós-Graduação em Engenharia de Software**, do Departamento de Informática da PUC-Rio.

Coordenação: **Prof. Marcos Kalinowski** (*kalinowski@inf.puc-rio.br*)

Mais informações em: https://especializacao.ccec.puc-rio.br/especializacao/engenharia-de-software
