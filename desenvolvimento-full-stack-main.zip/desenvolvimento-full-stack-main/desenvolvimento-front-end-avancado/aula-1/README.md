# Meu Front-end em React

Este é um projeto que faz parte do material diático da **Aula 1** da disciplina **Desenvolvimento Front-end Avançado** 

O objetivo aqui é ilutsrar o conteúdo apresentado na primeira aula com um código simples de front-end utilizando apenas HTML, CSS e o básico do JavaScript.

Neste projeto temos uma proposta de front-end para um sistema de vendas feito utilizando HTML, CSS e JavaScript. Essa proposta será no estilo SPA e ilustrará o desenvolvimento de uma pequena aplicação front-end que, por hora, não faz conexão com um servidor de dados.

Vamos explorar como criar a estrutura da página, introduzindo estilos aos componentes e interatividade à aplicação.

---
## Como executar?

Basta fazer o download do projeto e abrir o arquivo `index.html` no seu browser.
