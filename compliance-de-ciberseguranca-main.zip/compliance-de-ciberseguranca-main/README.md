Práticas das disciplinas da especialização online Pós-Graduação em **Compliance de Cibersegurança**, do Departamento de Informática da PUC-Rio.

Coordenação: **Prof. Anderson Oliveira da Silva** (*anderson@inf.puc-rio.br*)

Mais informações em: https://especializacao.ccec.puc-rio.br/especializacao/compliance-de-ciberseguranca
